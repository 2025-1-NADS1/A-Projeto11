﻿// See https://aka.ms/new-console-template for more information


using Microsoft.VisualBasic;
using System.Globalization;

Console.WriteLine("Hello, World!");


String[] x = msg.Split('S');
